HMENU findWindowMenu(HMENU hMenu);
