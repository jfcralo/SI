// TesteArmazem.cpp : Defines the entry point for the console application.
//

// Teste.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "interface.h"
#include "conio.h"
#include <windows.h>

bool getBit(uInt8 var, int nBit) {

	int result = var & (1 << nBit);
	return (result != 0);
}

void setBit(uInt8 &var, uInt8 nBit, bool value) {

	uInt8 mask_on = 1 << nBit;
	uInt8 mask_off = 0xff - mask_on;

	if (value == TRUE) {
		var = var | mask_on;
	}else {
		var = var & mask_off;
	}

	
}


int main()
{
	char c,b;
	int i=0;
	uInt8 port0, port1, port2, port3;
	uInt8 motores;
	
	create_DO_channel(0);
	create_DO_channel(1);
	create_DO_channel(2);
	create_DO_channel(3);
	create_DI_channel(4);
	create_DI_channel(5);

	printf("Start?\n");
	getchar();

	printf(" ___ \t\t ___\t\n");
	printf("|   |\t\t|   |\t\n");
	printf("| I |\t\t| w |\t\n");
	printf("|___|\t\t|___|\t\n");
	printf(" ___ \t ___ \t ___ \t ___\n");
	printf("|   |\t|   |\t|   |\t|   |\n");
	printf("| 0 |\t| a |\t| s |\t| d |\n");
	printf("|___|\t|___|\t|___|\t|___|\n");

	while (1) {
		
		port0 = ReadDigitalU8(0);
		port1 = ReadDigitalU8(1);
		port2 = ReadDigitalU8(2);
		port3 = ReadDigitalU8(3);
		motores = ReadDigitalU8(4);
		
		/*while (i < 10) {
			if (b=_kbhit()) {
				break;
			}
		}
		if (b != 0) {
			c = _getch();
		}
		else {
			c = '0';
		}*/
		c = _getch();
		
		printf("key pressed: %c\n", c);
		//while (c != NULL) {
			switch (c) {
				case'w':
					setBit(motores, 6, FALSE);
					setBit(motores, 5, TRUE);
					WriteDigitalU8(4, motores);
					break;
				case's':
					setBit(motores, 5, FALSE);
					setBit(motores, 6, TRUE);
					WriteDigitalU8(4, motores);
					break;
				case'a':
					setBit(motores, 0, FALSE);
					setBit(motores, 1, TRUE);
					WriteDigitalU8(4, motores);
					break;
				case'd':
					setBit(motores, 1, FALSE);
					setBit(motores, 0, TRUE);
					WriteDigitalU8(4, motores);
					break;
				case'i':
					WriteDigitalU8(4, 0);
					setBit(motores, 3, FALSE);
					setBit(motores, 4, TRUE);
					WriteDigitalU8(4, motores);
					break;
				case'o':
					setBit(motores, 4, FALSE);
					setBit(motores, 3, TRUE);
					WriteDigitalU8(4, motores);
					break;
				case '0':
					WriteDigitalU8(4, 0);
					break;
				default:
					printf("1-Check if CAPSLOCK is off\n");
					printf("2-Get your finger out of the SHIFT key\n");
					printf("3-Check if you pressed de right key\n");

			}
		
		FlushConsoleInputBuffer(stdin);
	}
	
	
	/*
	printf("Go?");
	getchar();
	setBit(motores, 3, TRUE);
	WriteDigitalU8(4, motores);

	while (getBit(read, 3)) {
		read = ReadDigitalU8(1);
	}

	setBit(motores, 3, FALSE);
	WriteDigitalU8(4, motores);

	Sleep(2000);

	setBit(motores, 1, TRUE);
	WriteDigitalU8(4, motores);

	read = ReadDigitalU8(0);

	while (getBit(read, 0)) {
		read = ReadDigitalU8(0);
	}

	WriteDigitalU8(4, 0);
	*/
	
	return 0;
}

